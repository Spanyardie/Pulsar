﻿using Pulsar.ObjectModel;
using Pulsar.ObjectModel.Primitives;
using System;
using System.Diagnostics;
using Urho;

namespace Pulsar.Helpers
{
    public static class GizmoHelper
    {
        public static void SetAsSelected(Node node, Gizmo gizmo, PulsarScene scene)
        {
            StaticModel nodeModel = node.GetComponent<StaticModel>();
            if (nodeModel != null)
            {
                MaterialTemp tempMaterial = new MaterialTemp(nodeModel, scene.GetApplication());
                if (tempMaterial != null)
                {
                    tempMaterial.Name = "materialTemp";
                    tempMaterial.SetTransparentMaterial();

                    node.AddComponent(tempMaterial);
                    if (gizmo != null)
                    {
                        gizmo.Node.Position = node.Position;
                        gizmo.SetGizmoVisible(true);
                        gizmo.Node.Enabled = true;
                    }
                }
            }
        }

        public static void UnSelect(Node node, Gizmo gizmo)
        {
            MaterialTemp matTemp = node.GetComponent<MaterialTemp>();
            if (matTemp != null)
            {
                matTemp.ResetMaterial();
                node.RemoveComponent(matTemp);
                if (gizmo != null)
                {
                    gizmo.SetGizmoVisible(false);
                    gizmo.Node.Enabled = false;
                }
            }
        }
    }
}
