﻿using Pulsar.ObjectModel.Primitives;
using Urho;

namespace Pulsar.ObjectModel
{
    public class PulsarCamera : Component
    {
        private PulsarScene _scene;
        private Node _node;
        private string _name;
        private BaseEntity _baseEntity;
        private Camera _camera;

        public bool InDesign { get; set; }

        public bool IsMainCamera { get; set; }

        public PulsarCamera(string name, PulsarScene scene)
        {
            _name = name;
            _scene = scene;

            if (_scene != null)
            {
                _node = _scene.CreateChild(_name);
                if (_node != null)
                {
                    _baseEntity = _node.CreateComponent<BaseEntity>();
                    _baseEntity.Name = name;
                    _baseEntity.Node = _node;
                    _baseEntity.PulsarScene = scene;
                    CreateEntity();
                }
            }
        }
        public PulsarCamera(string name, PulsarScene scene, DebugRenderer debugRenderer)
        {
            _name = name;
            _scene = scene;

            if (_scene != null)
            {
                _node = _scene.CreateChild(_name);
                if (_node != null)
                {
                    _baseEntity = _node.CreateComponent<BaseEntity>();
                    _baseEntity.Name = name;
                    _baseEntity.Node = _node;
                    _baseEntity.PulsarScene = scene;
                    CreateEntity();
                    _baseEntity.SetDebugRenderer(debugRenderer);
                    _camera.DrawDebugGeometry(debugRenderer, false);
                }
            }
        }

        public void SetDebugRenderer(DebugRenderer debugRenderer)
        {
            if (_baseEntity != null)
            {
                _baseEntity.SetDebugRenderer(debugRenderer);
            }
        }

        public DebugRenderer GetDebugRenderer()
        {
            if (_baseEntity != null)
            {
                return _baseEntity.GetDebugRenderer();
            }

            return null;
        }

        public void SetPosition(Vector3 position)
        {
            if (_baseEntity != null)
                _baseEntity.SetPosition(position);
        }

        public void CreateEntity()
        {
            _camera = _node.CreateComponent<Camera>();

            _baseEntity.CreateEntity();
            if (_baseEntity.HasGizmo)
                _baseEntity.GetGizmo().Enabled = false;
        }

        public Camera Camera
        {
            get
            {
                return _camera;
            }
            set
            {
                _camera = value;
            }
        }

        public Node Node
        {
            get
            {
                return _node;
            }
            set
            {
                _node = value;
            }
        }
    }
}
