﻿using Pulsar.ObjectModel.Interfaces;
using Pulsar.ObjectModel.Primitives;
using Urho;

namespace Pulsar.ObjectModel
{
    public class PulsarLight : Urho.Component, IBaseEntity
    {
        private PulsarScene _scene;
        private Node _node;
        private string _name;
        private BaseEntity _baseEntity;
        private Light _light;

        public bool InDesign { get; set; }

        public PulsarLight(string name)
        {
            _name = name;
        }

        public void SetDebugRenderer(DebugRenderer debugRenderer)
        {
            if (_baseEntity != null)
            {
                _baseEntity.SetDebugRenderer(debugRenderer);
            }
        }

        public DebugRenderer GetDebugRenderer()
        {
            if (_baseEntity != null)
            {
                return _baseEntity.GetDebugRenderer();
            }

            return null;
        }

        public void SetPosition(Vector3 position)
        {
            if (_baseEntity != null)
                _baseEntity.SetPosition(position);
        }

        public void CreateEntity()
        {
            _light = _node.CreateComponent<Light>();

        }

        public void SetDirection(Vector3 direction)
        {
            if (_node != null)
            {
                _node.SetDirection(direction);
            }
        }

        public Light Light
        {
            get
            {
                return _light;
            }
            set
            {
                _light = value;
            }
        }

        public void SetNode(Node node)
        {
            _node = node;
        }

        public void SetScene(PulsarScene scene)
        {
            _scene = scene;
        }

        public void SetInDesign(bool isInDesign)
        {
            InDesign = isInDesign;
        }

        public void SetBaseEntity(BaseEntity baseEntity)
        {
            _baseEntity = baseEntity;
        }

        public Node GetNode()
        {
            return _node;
        }

        public PulsarScene GetScene()
        {
            return _scene;
        }

        public BaseEntity GetBaseEntity()
        {
            return _baseEntity;
        }

        public string GetEntityName()
        {
            return _name; ;
        }
    }
}
