﻿using Pulsar.Helpers;
using Pulsar.ObjectModel.Interfaces;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing.Design;
using System.Linq;
using Urho;

namespace Pulsar.ObjectModel.Primitives
{
    public class BaseEntity : Urho.Component
    {
        private string _name;
        private PulsarScene _scene;
        private Node _node;
        private DebugRenderer _debugRenderer;

        private Vector3 _position;
        private Vector3 _scale;
        private Vector3 _previousScale;
        private Vector3 _rotation;
        private Quaternion _quaternionRotation;

        //private Material _material;

        private bool _enabled;

        private Collection<Urho.Component> _components;
        private bool _isSelected;
        private bool _previousSelectedValue;
        private Gizmo _gizmo;
        private bool _hasGizmo = true;
        public bool InDesign { get; set; }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public bool HasGizmo
        {
            get
            {
                return _hasGizmo;
            }
            private set { }
        }

        public bool IsSelected
        {
            get
            {
                return _isSelected;
            }
            set
            {
                _previousSelectedValue = _isSelected;
                _isSelected = value;
                //when changed also change the gizmo for this object
                if (_gizmo != null)
                {
                    if (_previousSelectedValue != _isSelected)
                    {
                        if (value)
                        {
                            SetAsSelected();
                        }
                        else
                        {
                            UnSelect();
                        }
                    }
                }
            }
        }

        [Browsable(false)]
        public PulsarScene PulsarScene
        {
            get
            {
                return _scene;
            }
            set
            {
                _scene = value;
            }
        }

        [Category("Translation")]
        [Editor(typeof(Vector3Editor), typeof(UITypeEditor))]
        [Vector3Editor.LabelText("Position")]
        public Vector3 Position
        {
            get
            {
                return _position;
            }
            set
            {
                _position = value;
                if (_gizmo != null) { _gizmo.Node.Position = value; }
            }
        }

        [Category("Translation")]
        [Editor(typeof(Vector3Editor), typeof(UITypeEditor))]
        [Vector3Editor.LabelText("Rotation")]
        public Vector3 Rotation
        {
            get
            {
                return _rotation;
            }
            set
            {
                _rotation = value;
                _quaternionRotation = new Quaternion(_rotation.X, _rotation.Y, _rotation.Z, 1);

            }
        }

        [Browsable(false)]
        public Quaternion QuaternionRotation
        {
            get
            {
                return _quaternionRotation;
            }
            private set { }
        }

        [Browsable(false)]
        public new Node Node
        {
            get
            {
                return _node;
            }
            set
            {
                _node = value;
            }
        }

        public Vector3 Scale
        {
            get
            {
                return _scale;
            }
            set
            {
                _scale = value;
                if (_gizmo != null)
                {
                    _gizmo.Size = _scale;
                    ResetGizmo();
                }
            }
        }

        private void ResetGizmo()
        {
            _gizmo.RemoveGeometry();
            _gizmo.Initialise();
        }

        [Browsable(false)]
        public Collection<Urho.Component> Components
        {
            get
            {
                return _components;
            }
            private set { }
        }

        public BaseEntity()
        {
            _components = new Collection<Urho.Component>();
        }

        public BaseEntity(string name, PulsarScene scene)
        {
            _components = new Collection<Urho.Component>();

            _name = name;
            _scene = scene;

            if (scene != null)
                _node = scene.CreateChild(_name);
        }

        public BaseEntity(string name, PulsarScene scene, DebugRenderer debugRenderer)
        {
            _components = new Collection<Urho.Component>();

            _name = name;
            _scene = scene;
            _debugRenderer = debugRenderer;

            if (_scene != null)
                _node = scene.CreateChild(_name);
        }

        public BaseEntity(string name, PulsarScene scene, DebugRenderer debugRenderer, Vector3 position)
        {
            _components = new Collection<Urho.Component>();

            _name = name;
            _scene = scene;
            _debugRenderer = debugRenderer;

            if (_scene != null)
                _node = scene.CreateChild(_name);

            SetPosition(position);
            CreateEntity();
        }

        public BaseEntity(string name, PulsarScene scene, DebugRenderer debugRenderer, Vector3 position, Vector3 rotation)
        {
            _components = new Collection<Urho.Component>();

            _name = name;
            _scene = scene;
            _debugRenderer = debugRenderer;

            if (_scene != null)
                _node = scene.CreateChild(_name);

            SetPosition(position);
            SetRotation(rotation);
            CreateEntity();
        }

        public BaseEntity(string name, PulsarScene scene, DebugRenderer debugRenderer, Vector3 position, Vector3 rotation, Vector3 scale)
        {
            _components = new Collection<Urho.Component>();

            _name = name;
            _scene = scene;
            _debugRenderer = debugRenderer;

            if (_scene != null)
                _node = scene.CreateChild(_name);

            SetPosition(position);
            SetRotation(rotation);
            SetScale(scale);
            CreateEntity();
        }

        public virtual void SetPosition(Vector3 position)
        {
            if (_node != null)
                _node.Position = position;
        }

        public virtual void SetRotation(Vector3 rotation)
        {
            if (_node != null)
                _node.Rotation = new Quaternion(rotation.X, rotation.Y, rotation.Z);
        }

        public virtual void SetScale(Vector3 scale)
        {
            if (_node != null)
                _node.Scale = scale;
        }

        public virtual void SetDebugRenderer(DebugRenderer renderer)
        {
            _debugRenderer = renderer;
        }

        public virtual DebugRenderer GetDebugRenderer()
        {
            return _debugRenderer;
        }

        public virtual void AddComponent(Urho.Component component)
        {
            if (component != null)
            {
                // make sure this component does not already exist in the list
                var existingEntity = _components.ToList().Find(entity => entity.Equals(component));

                if (existingEntity == null)
                {
                    IBaseEntity baseEntity = (IBaseEntity)component;
                    if (baseEntity != null)
                    {
                        baseEntity.SetDebugRenderer(_debugRenderer);
                        baseEntity.SetInDesign(InDesign);
                        baseEntity.SetNode(_node);
                        baseEntity.SetScene(_scene);
                        baseEntity.SetBaseEntity(this);
                    }
                    _node.AddComponent(component);
                    _components.Add(component);
                }
            }
        }

        public virtual void RemoveComponent(Urho.Component component)
        {
            if (component != null)
            {
                _components.Remove(component);
            }
        }
        public virtual void SetAsSelected()
        {
            GizmoHelper.SetAsSelected(_node, _gizmo, _scene);
            _isSelected = true;
        }

        public virtual void UnSelect()
        {
            GizmoHelper.UnSelect(_node, _gizmo);
            _isSelected = false;
        }

        private void CreateGizmo()
        {
            var gizmoNode = _scene.CreateChild(_node.Name + "_gizmo");
            _gizmo = new Gizmo(_node.Name + "_gizmo", _scene, gizmoNode, this);
            gizmoNode.AddComponent(_gizmo);
            _gizmo.Node.Position = _node.Position;

            //grab the bounds of the entity
            _gizmo.Size = _scale;
            _gizmo.Node.Enabled = false;
            _gizmo.Initialise();
            _gizmo.SetGizmoVisible(false);

            _hasGizmo = true;
        }

        public virtual void CreateEntity()
        {
            if (_gizmo == null) CreateGizmo();
        }

        public Gizmo GetGizmo()
        {
            return _gizmo;
        }
    }
}
