﻿using System.ComponentModel;
using Urho;

namespace Pulsar.ObjectModel.PropertiesModel
{
    public class CameraProperties : NodeProperties
    {
        private float _aspectRatio;
        private bool _autoAspectRatio;
        private float _farClip;
        private float _nearClip;
        private bool _useClipping;
        private bool _flipVertical;
        private float _skew;
        private float _fieldOfView;
        private float _levelOfDetailBias;
        private float _zoom;
        private uint _viewMask;
        private bool _orthographic;
        private float _orthographicSize;
        private Camera _node;

        private bool _isMainCamera = false;

        private bool _externallySet;

        [Browsable(false)]
        public bool ExternallySet
        {
            get
            {
                return _externallySet;
            }
            set
            {
                _externallySet = value;
            }
        }

        [ReadOnly(true)]
        [Category("Node")]
        public bool IsMainCamera
        {
            get
            {
                return _isMainCamera;
            }
            set
            {
                _isMainCamera = value;
            }
        }

        [Browsable(false)]
        public new Camera Node
        {
            get
            {
                return _node;
            }
            set
            {
                _node = value;
                base.Node = _node.Node;
            }
        }

        [Browsable(false)]
        public override PulsarApplication PulsarApplication
        {
            get
            {
                return base.PulsarApplication;
            }
            set
            {
                base.PulsarApplication = value;
            }
        }

        [Browsable(false)]
        public override PulsarScene Scene
        {
            get
            {
                return base.Scene;
            }
            set
            {
                base.Scene = value;
            }
        }

        public override Vector3 Position
        {
            get => base.Position;
            set
            {
                base.Position = value;
                Application.InvokeOnMain(Update);
            }
        }

        public override Quaternion Rotation
        {
            get => base.Rotation;
            set
            {
                base.Rotation = value;
                Application.InvokeOnMain(Update);
            }
        }

        public override Vector3 Scale
        {
            get => base.Scale;
            set
            {
                base.Scale = value;
                Application.InvokeOnMain(Update);
            }
        }

        public override string Name
        {
            get => base.Name;
            set
            {
                if (!_isMainCamera)
                {
                    base.Name = value;
                    Application.InvokeOnMain(Update);
                }
            }
        }

        public override bool Enabled
        {
            get => base.Enabled;
            set
            {
                base.Enabled = value;
                Application.InvokeOnMain(Update);
            }
        }

        [Category("Aspect Ratio")]
        public float AspectRatio
        {
            get
            {
                return _aspectRatio;
            }
            set
            {
                _aspectRatio = value;
                Application.InvokeOnMain(Update);
            }
        }

        [Category("Aspect Ratio")]
        public bool AutoAspectRatio
        {
            get
            {
                return _autoAspectRatio;
            }
            set
            {
                _autoAspectRatio = value;
                Application.InvokeOnMain(Update);
            }
        }



        [Category("Clipping")]
        public float FarClip
        {
            get
            {
                return _farClip;
            }
            set
            {
                _farClip = value;
                Application.InvokeOnMain(Update);
            }
        }


        [Category("Clipping")]
        public float NearClip
        {
            get
            {
                return _nearClip;
            }
            set
            {
                _nearClip = value;
                Application.InvokeOnMain(Update);
            }
        }


        [Category("Clipping")]
        public bool UseClipping
        {
            get
            {
                return _useClipping;
            }
            set
            {
                _useClipping = value;
                Application.InvokeOnMain(Update);
            }
        }



        [Category("Effect")]
        public bool FlipVertical
        {
            get
            {
                return _flipVertical;
            }
            set
            {
                _flipVertical = value;
                Application.InvokeOnMain(Update);
            }
        }


        [Category("Effect")]
        public float Skew
        {
            get
            {
                return _skew;
            }
            set
            {
                _skew = value;
                Application.InvokeOnMain(Update);
            }
        }



        [Category("View")]
        public float FieldOfView
        {
            get
            {
                return _fieldOfView;
            }
            set
            {
                _fieldOfView = value;
                Application.InvokeOnMain(Update);
            }
        }


        [Category("View")]
        public float LevelOfDetailBias
        {
            get
            {
                return _levelOfDetailBias;
            }
            set
            {
                _levelOfDetailBias = value;
                Application.InvokeOnMain(Update);
            }
        }


        [Category("View")]
        public float Zoom
        {
            get
            {
                return _zoom;
            }
            set
            {
                _zoom = value;
                Application.InvokeOnMain(Update);
            }
        }


        [Category("View")]
        public uint ViewMask
        {
            get
            {
                return _viewMask;
            }
            set
            {
                _viewMask = value;
                Application.InvokeOnMain(Update);
            }
        }



        [Category("Orthographic")]
        public bool Orthographic
        {
            get
            {
                return _orthographic;
            }
            set
            {
                _orthographic = value;
                Application.InvokeOnMain(Update);
            }
        }


        [Category("Orthographic")]
        public float OrthographicSize
        {
            get
            {
                return _orthographicSize;
            }
            set
            {
                _orthographicSize = value;
                Application.InvokeOnMain(Update);
            }
        }

        public CameraProperties(string name)
        {
            Name = name;
        }

        public override void Update()
        {
            base.Update();

            if (Node != null)
            {
                if (Scene != null)
                {
                    var cameraNode = Node.GetComponent<Camera>();
                    if (cameraNode != null)
                    {
                        cameraNode.Node.Position = Position;
                        cameraNode.Node.Rotation = Rotation;
                        cameraNode.Node.Scale = Scale;
                        cameraNode.Node.Name = Name;
                        cameraNode.Node.Enabled = Enabled;

                        cameraNode.AspectRatio = AspectRatio;
                        cameraNode.AutoAspectRatio = AutoAspectRatio;
                        cameraNode.FarClip = FarClip;
                        cameraNode.NearClip = NearClip;
                        cameraNode.UseClipping = UseClipping;
                        cameraNode.FlipVertical = FlipVertical;
                        cameraNode.Skew = Skew;
                        cameraNode.Fov = FieldOfView;
                        cameraNode.LodBias = LevelOfDetailBias;
                        cameraNode.Zoom = Zoom;
                        cameraNode.ViewMask = ViewMask;
                        cameraNode.Orthographic = Orthographic;
                        cameraNode.OrthoSize = OrthographicSize;
                    }
                }
                if (PulsarApplication != null && Scene != null)
                {
                    PulsarApplication.DisplayScene = Scene;
                }
            }
        }
    }
}
