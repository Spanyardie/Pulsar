﻿using Pulsar.Helpers;
using Pulsar.ObjectModel.Messaging;
using Pulsar.ObjectModel.Primitives;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing.Design;
using Urho;

namespace Pulsar.ObjectModel.PropertiesModel
{
    public class NodeProperties
    {
        public delegate void NodeNameChangedEventHandler(string oldName, string newName);
        public event NodeNameChangedEventHandler SceneNodeNameChanged;

        [Browsable(false)]
        public virtual Node Node { get; set; }
        [Browsable(false)]
        public virtual PulsarApplication PulsarApplication { get; set; }
        [Browsable(false)]
        public virtual PulsarScene Scene { get; set; }
        [Browsable(false)]
        public bool UpdateComplete { get; set; }

        private Vector3 _position;
        private Quaternion _rotation;
        private Vector3 _scale;
        private string _name;
        private string _previousNodeName;
        private bool _nameChanged = false;
        private bool _enabled;
        private bool _externallySet;
        private bool _inCreation;
        [Browsable(false)]
        public long ID { get; private set; }

        public NodeProperties()
        {
            GenerateID();

        }

        [Browsable(false)]
        public string NodeName
        {
            get
            {
                if (Node != null)
                {
                    return Node.Name;
                }
                else
                {
                    return "";
                }
            }
        }

        [Browsable(false)]
        public bool InCreation
        {
            get
            {
                return _inCreation;
            }
            set
            {
                _inCreation = value;
            }
        }

        [Browsable(false)]
        public bool ExternallySet
        {
            get
            {
                return _externallySet;
            }
            set
            {
                _externallySet = value;
            }
        }

        [Browsable(false)]
        public virtual string PreviousNodeName
        {
            get
            {
                return _previousNodeName;
            }
            set
            {
                _previousNodeName = value;
            }
        }

        [Category("Translation")]
        [Editor(typeof(Vector3Editor), typeof(UITypeEditor))]
        [Vector3Editor.LabelText("Position")]
        public virtual Vector3 Position
        {
            get
            {
                return _position;
            }
            set
            {
                _position = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Translation")]
        public virtual Quaternion Rotation
        {
            get
            {
                return _rotation;
            }
            set
            {
                _rotation = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Translation")]
        [Editor(typeof(Vector3Editor), typeof(UITypeEditor))]
        [Vector3Editor.LabelText("Scale")]
        public virtual Vector3 Scale
        {
            get
            {
                return _scale;
            }
            set
            {
                _scale = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Node")]
        public virtual string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (!IsNameUniqueInScene(value)) return;

                _name = value;
                Application.InvokeOnMain(Update);
                if (!_externallySet)
                {
                    if (_previousNodeName != null)
                    {
                        PulsarMessage message = new PulsarMessage
                        {
                            Type = PulsarMessage.MessageType.NodeNameChanged,
                            Iterations = 1
                        };
                        message.Properties.Add("oldNodeName", _previousNodeName);
                        message.Properties.Add("newNodeName", _name);
                        //this change is dependent on Update completing first
                        Dependency dependency = new Dependency()
                        {
                            Source = this,
                            Property = "UpdateComplete",
                            Value = true
                        };
                        message.Dependencies.Add(dependency);
                        dependency = new Dependency()
                        {
                            Source = this,
                            Property = "NodeName",
                            Value = _name
                        };
                        message.Dependencies.Add(dependency);


                        if (message != null)
                            PulsarApplication.MessageQueue.PushMessage(message);
                    }
                }
                _previousNodeName = _name;
            }
        }

        private bool IsNameUniqueInScene(string value)
        {
            bool nameIsUnique = true;

            if (Scene != null)
            {
                foreach (Node node in Scene.Children)
                {
                    if (node != null)
                    {
                        if (!node.Equals(Node))
                        {
                            if (node.Name == value)
                            {
                                nameIsUnique = false;
                                break;
                            }
                        }
                    }
                }
            }

            return nameIsUnique;
        }

        [Category("Node")]
        public virtual bool Enabled
        {
            get
            {
                return _enabled;
            }
            set
            {
                _enabled = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        public virtual void Update()
        {
            string oldNodeName = "";
            bool nameIsChanged = false;

            if (_inCreation)
            {
                Debug.Print("NodeProperties.Update - UPDATE OCCURRED DURING CREATION - EXITING!");
                return;
            }

            if (Node != null)
            {
                UpdateComplete = false;

                if (!_externallySet)
                {
                    Node.Position = Position;
                    Node.Rotation = Rotation;
                    Node.Scale = Scale;

                    if (Node.Name != Name)
                    {
                        nameIsChanged = true;
                    }

                    oldNodeName = Node.Name;
                    if (Node.Name != Name)
                        Debug.Print("NodeProperties.Update - Setting node '" + Node.Name + "' with new name '" + Name + "'");
                    Node.Name = Name;
                    Node.Enabled = Enabled;

                    if (Scene != null)
                    {
                        var sceneNode = Scene.GetChild(Node.Name);
                        if (sceneNode != null)
                        {
                            sceneNode.Name = Name;
                            sceneNode.Enabled = Enabled;
                            sceneNode.Position = Position;
                            sceneNode.Rotation = Rotation;
                            sceneNode.Scale = Scale;

                            //does this node contain any components that need updating?
                            if (sceneNode.Components.Count > 0)
                            {
                                var baseEntity = Node.GetComponent<BaseEntity>();
                                if (baseEntity != null)
                                {
                                    baseEntity.Name = Name;
                                    baseEntity.Position = Position;
                                    baseEntity.Rotation = Rotation.ToEulerAngles();
                                    baseEntity.Scale = Scale;
                                    baseEntity.Enabled = Enabled;
                                }
                            }
                            //if the name has changed also change the name of an associated gizmo
                            Node gizmo = Scene.GetChild(oldNodeName + "_gizmo");
                            if (gizmo != null)
                            {
                                gizmo.Name = Name + "_gizmo";
                            }
                        }
                    }
                    if (PulsarApplication != null && Scene != null)
                    {
                        PulsarApplication.DisplayScene = Scene;
                    }
                    UpdateComplete = true;
                }
            }
        }

        private void GenerateID()
        {
            //generate an ID from the current tick 
            ID = DateTime.Now.Ticks;
        }
    }
}
