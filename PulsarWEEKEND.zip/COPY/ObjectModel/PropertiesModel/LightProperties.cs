﻿using System.ComponentModel;
using System.Linq;
using Urho;

namespace Pulsar.ObjectModel.PropertiesModel
{
    public class LightProperties : NodeProperties
    {
        private Color _color;
        private Color _colorFromTemperature;
        private Color _effectiveColor;

        private float _aspectRatio;
        private float _brightness;
        private float _temperature;
        private bool _usePhysicalValues;
        private float _effectiveSpecularIntensity;
        private float _specularIntensity;
        private float _fadeDistance;
        private float _fieldOfView;
        private float _length;
        private LightType _lightType;
        private bool _perVertex;
        private float _radius;
        private float _range;
        private float _shadowFadeDistance;
        private float _shadowIntensity;
        private float _shadowMaximumExtrusion;
        private float _shadowNearFarRatio;
        private float _shadowResolution;
        private Light _node;
        private bool _externallySet;

        [Browsable(false)]
        public bool ExternallySet
        {
            get
            {
                return _externallySet;
            }
            set
            {
                _externallySet = value;
            }
        }

        public new Light Node
        {
            get
            {
                return _node;
            }
            set
            {
                _node = value;
                base.Node = _node.Node;
            }
        }

        [Category("Aspect")]
        public float AspectRatio
        {
            get
            {
                return _aspectRatio;
            }
            set
            {
                _aspectRatio = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Colour")]
        public float Brightness
        {
            get
            {
                return _brightness;
            }
            set
            {
                _brightness = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Colour")]
        public System.Drawing.Color Colour
        {
            get
            {
                System.Drawing.Color color = System.Drawing.Color.Empty;

                if (_color != null)
                {
                    color = System.Drawing.Color.FromArgb((int)_color.A, (int)_color.R, (int)_color.G, (int)_color.B);
                }
                return color;
            }

            set
            {
                _color = new Color
                {
                    A = value.A,
                    R = value.R,
                    G = value.G,
                    B = value.B
                };
                Urho.Application.InvokeOnMain(Update);
            }
        }
        [Category("Colour")]
        public System.Drawing.Color ColourFromTemperature
        {
            get
            {
                System.Drawing.Color color = System.Drawing.Color.Empty;

                if (_colorFromTemperature != null)
                {
                    color = System.Drawing.Color.FromArgb((int)_colorFromTemperature.A, (int)_colorFromTemperature.R, (int)_colorFromTemperature.G, (int)_colorFromTemperature.B);
                }
                return color;
            }

            set
            {
                _colorFromTemperature = new Color
                {
                    A = value.A,
                    R = value.R,
                    G = value.G,
                    B = value.B
                };
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Colour")]
        public System.Drawing.Color EffectiveColour
        {
            get
            {
                System.Drawing.Color color = System.Drawing.Color.Empty;

                if (_effectiveColor != null)
                {
                    color = System.Drawing.Color.FromArgb((int)_effectiveColor.A, (int)_effectiveColor.R, (int)_effectiveColor.G, (int)_effectiveColor.B);
                }
                return color;
            }

            set
            {
                _effectiveColor = new Color
                {
                    A = value.A,
                    R = value.R,
                    G = value.G,
                    B = value.B
                };
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Colour")]
        public float Temperature
        {
            get
            {
                return _temperature;
            }
            set
            {
                _temperature = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Colour")]
        public bool UsePhysicalValues
        {
            get
            {
                return _usePhysicalValues;
            }
            set
            {
                _usePhysicalValues = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Intensity")]
        public float EffectiveSpecularIntensity
        {
            get
            {
                return _effectiveSpecularIntensity;
            }
            set
            {
                _effectiveSpecularIntensity = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Intensity")]
        public float SpecularIntensity
        {
            get
            {
                return _specularIntensity;
            }
            set
            {
                _specularIntensity = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Length")]
        public float FadeDistance
        {
            get
            {
                return _fadeDistance;
            }
            set
            {
                _fadeDistance = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Length")]
        public float FieldOfView
        {
            get
            {
                return _fieldOfView;
            }
            set
            {
                _fieldOfView = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Length")]
        public float Length
        {
            get
            {
                return _length;
            }
            set
            {
                _length = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Type")]
        public LightType LightType
        {
            get
            {
                return _lightType;
            }
            set
            {
                _lightType = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Range")]
        public bool PerVertex
        {
            get
            {
                return _perVertex;
            }
            set
            {
                _perVertex = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Range")]
        public float Radius
        {
            get
            {
                return _radius;
            }
            set
            {
                _radius = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Range")]
        public float Range
        {
            get
            {
                return _range;
            }
            set
            {
                _range = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Shadow")]
        public float ShadowFadeDistance
        {
            get
            {
                return _shadowFadeDistance;
            }
            set
            {
                _shadowFadeDistance = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Shadow")]
        public float ShadowIntensity
        {
            get
            {
                return _shadowIntensity;
            }
            set
            {
                _shadowIntensity = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Shadow")]
        public float ShadowMaximumExtrusion
        {
            get
            {
                return _shadowMaximumExtrusion;
            }
            set
            {
                _shadowMaximumExtrusion = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Shadow")]
        public float ShadowNearFarRatio
        {
            get
            {
                return _shadowNearFarRatio;
            }
            set
            {
                _shadowNearFarRatio = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        [Category("Shadow")]
        public float ShadowResolution
        {
            get
            {
                return _shadowResolution;
            }
            set
            {
                _shadowResolution = value;
                Urho.Application.InvokeOnMain(Update);
            }
        }

        public override void Update()
        {
            base.Update();

            if (Node != null)
            {
                var lightNode = Node.GetComponent<Light>();
                lightNode.AspectRatio = AspectRatio;
                lightNode.Brightness = Brightness;
                lightNode.Color = new Color(Colour.R, Colour.G, Colour.B, Colour.A);
                lightNode.Temperature = Temperature;
                lightNode.UsePhysicalValues = UsePhysicalValues;
                lightNode.SpecularIntensity = SpecularIntensity;
                lightNode.FadeDistance = FadeDistance;
                lightNode.Fov = FieldOfView;
                lightNode.Length = Length;
                lightNode.LightType = LightType;
                lightNode.PerVertex = PerVertex;
                lightNode.Range = Range;
                lightNode.Radius = Radius;
                lightNode.ShadowFadeDistance = ShadowFadeDistance;
                lightNode.ShadowIntensity = ShadowIntensity;
                lightNode.ShadowMaxExtrusion = ShadowMaximumExtrusion;
                lightNode.ShadowNearFarRatio = ShadowNearFarRatio;
                lightNode.ShadowResolution = ShadowResolution;

                if (Scene != null)
                {
                    var sceneNode = Scene.Children.ToList().Find(node => node.Name == lightNode.Node.Name);
                    if (sceneNode != null)
                    {
                        Light sceneLight = sceneNode.GetComponent<Light>();
                        if (sceneLight != null)
                        {
                            sceneLight.AspectRatio = AspectRatio;
                            sceneLight.Brightness = Brightness;
                            sceneLight.Color = new Color(Colour.R, Colour.G, Colour.B, Colour.A);
                            sceneLight.Temperature = Temperature;
                            sceneLight.UsePhysicalValues = UsePhysicalValues;
                            sceneLight.SpecularIntensity = SpecularIntensity;
                            sceneLight.FadeDistance = FadeDistance;
                            sceneLight.Fov = FieldOfView;
                            sceneLight.Length = Length;
                            sceneLight.LightType = LightType;
                            sceneLight.PerVertex = PerVertex;
                            sceneLight.Range = Range;
                            sceneLight.Radius = Radius;
                            sceneLight.ShadowFadeDistance = ShadowFadeDistance;
                            sceneLight.ShadowIntensity = ShadowIntensity;
                            sceneLight.ShadowMaxExtrusion = ShadowMaximumExtrusion;
                            sceneLight.ShadowNearFarRatio = ShadowNearFarRatio;
                            sceneLight.ShadowResolution = ShadowResolution;
                        }
                    }
                }
                if (PulsarApplication != null && Scene != null)
                {
                    PulsarApplication.DisplayScene = Scene;
                }
            }
        }
    }
}
