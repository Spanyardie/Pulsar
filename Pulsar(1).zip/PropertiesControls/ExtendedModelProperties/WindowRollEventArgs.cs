﻿using System;

namespace ExtendedModelProperties
{
    public class WindowRollEventArgs : EventArgs
    {
        public ModelProperties.WindowRoll WindowRoll { get; set; }
    }
}