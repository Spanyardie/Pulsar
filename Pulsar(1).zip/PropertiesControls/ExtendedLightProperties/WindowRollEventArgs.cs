﻿using System;

namespace ExtendedLightProperties
{
    public class WindowRollEventArgs : EventArgs
    {
        public LightProperties.WindowRoll WindowRoll { get; set; }
    }
}
