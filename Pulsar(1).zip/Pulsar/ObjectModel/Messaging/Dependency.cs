﻿namespace Pulsar.ObjectModel.Messaging
{
    public class Dependency
    {
        public object Source { get; set; }
        public string Property { get; set; }
        public object Value { get; set; }
    }
}
