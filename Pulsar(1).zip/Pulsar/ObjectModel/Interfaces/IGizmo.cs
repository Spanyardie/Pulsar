﻿namespace Pulsar.ObjectModel.Interfaces
{
    public interface IGizmo
    {
        void SetAsSelected();

        void UnSelect();
    }
}
